package com.delta.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.content.Intent;
import android.view.Menu;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    EditText FirstNameEditText,LastNameEditText,userEmail,corpName,smNumber,UserPassEditText,confirmPassEditText,dob;
    RadioGroup gender;
    RadioButton male,female;
    Button RegisterButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        RegisterButton=(Button)findViewById(R.id.registerBtn);
        FirstNameEditText=(EditText)findViewById(R.id.firstname_edittext);
        LastNameEditText=(EditText)findViewById(R.id.lastname_edittext);
        userEmail=(EditText)findViewById(R.id.email_edittext);
        corpName=(EditText)findViewById(R.id.corpName);
        smNumber=(EditText)findViewById(R.id.smNumber);
        UserPassEditText = (EditText)findViewById(R.id.password_edittext);
        confirmPassEditText=(EditText)findViewById(R.id.password_again_edittext);
        male=(RadioButton)findViewById(R.id.male);
        female=(RadioButton)findViewById(R.id.female);
        gender=(RadioGroup)findViewById(R.id.gender_radiogroup);
    }
    public void onRegisterClick(View view) {

        final String FirstName = FirstNameEditText.getText().toString();
        final String LastName = LastNameEditText.getText().toString();
        final String email = userEmail.getText().toString();
        final String corpNameText = corpName.getText().toString();
        final String smNum = smNumber.getText().toString();
        final String passwordText = UserPassEditText.getText().toString();
        final String confirmPassword = confirmPassEditText.getText().toString();
       // final String male = male.getText().toString();
       // final String female = fem.getText().toString();


        if (FirstName.length() == 0)

        {
            FirstNameEditText.requestFocus();
            FirstNameEditText.setError("FIELD CANNOT BE EMPTY");
        } else if (!FirstName.matches("[a-zA-Z ]+")) {
            FirstNameEditText.requestFocus();
            FirstNameEditText.setError("ENTER ONLY ALPHABETICAL CHARACTER");
        }
        else if (LastName.length() == 0)
        {
            LastNameEditText.requestFocus();
            LastNameEditText.setError("FIELD CANNOT BE EMPTY");
        } else if (!LastName.matches("[a-zA-Z ]+")) {
            LastNameEditText.requestFocus();
            LastNameEditText.setError("ENTER ONLY ALPHABETICAL CHARACTER");
        }
        else if (email.length() == 0)
        {
            userEmail.requestFocus();
            userEmail.setError("FIELD CANNOT BE EMPTY");
        } else if (!email.matches("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$")) {
            userEmail.requestFocus();
            userEmail.setError("ENTER VALID EMAIL");
        }
        else if (corpNameText.length() == 0)
        {
            corpName.requestFocus();
            corpName.setError("FIELD CANNOT BE EMPTY");
        } else if (!corpNameText.matches("[a-zA-Z ]+")) {
            corpName.requestFocus();
            corpName.setError("ENTER ONLY ALPHABETICAL CHARACTER");
        }
        else if (smNum.length() == 0)

        {
            smNumber.requestFocus();
            smNumber.setError("FIELD CANNOT BE EMPTY");
        }
        else if(passwordText.length()==0)
        {
            UserPassEditText.requestFocus();
            UserPassEditText.setError("FIELD CANNOT BE EMPTY");
        }
        else if (confirmPassword.length() == 0)
        {
            confirmPassEditText.requestFocus();
            confirmPassEditText.setError("FIELD CANNOT BE EMPTY");
        } else if (!confirmPassword.equals(passwordText)) {
            confirmPassEditText.requestFocus();
            confirmPassEditText.setError("CONFIRM PASSWORD DOSEN'T MATCH");
        }
        else if (!male.isChecked() && !female.isChecked())
        {
            gender.requestFocus();
            Toast.makeText(this, "Please choose gender",
                    Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(RegisterActivity.this,"Validation Successful",Toast.LENGTH_LONG).show();
        }
    }
}
