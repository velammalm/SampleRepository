package com.delta.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.TextView;

public class DashboardActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        String smNumber="53453453454";
        TextView sn=(TextView)findViewById(R.id.sm_number);
        sn.setText(smNumber);
        String totalPoints="1000";
        TextView tp=(TextView)findViewById(R.id.points_earned);
        tp.setText(totalPoints);
    }
    public void progressClick(View v){
        startActivity(new Intent(DashboardActivity.this, GraphActivity.class));
    }
}
