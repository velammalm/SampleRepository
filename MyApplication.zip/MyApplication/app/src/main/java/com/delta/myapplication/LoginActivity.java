package com.delta.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.content.Intent;
import android.view.Menu;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText NameEditText,passEditText;

    Button RegistrationButton;
    Button LoginButton;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        RegistrationButton=(Button)findViewById(R.id.register);
        LoginButton=(Button)findViewById(R.id.loginButton);
        NameEditText=(EditText)findViewById(R.id.username);
        passEditText = (EditText)findViewById(R.id.password);
    }
    public void enrollClick(View v){
        startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
    }
    public void onClick(View view) {

        final String Name = NameEditText.getText().toString();
        final String password = passEditText.getText().toString();
        if (Name.length() == 0)

        {
            NameEditText.requestFocus();
            NameEditText.setError("FIELD CANNOT BE EMPTY");
        } else if (!Name.matches("[a-zA-Z ]+")) {
            NameEditText.requestFocus();
            NameEditText.setError("ENTER ONLY ALPHABETICAL CHARACTER");
        }
        else if(password.length()==0)
        {
            passEditText.requestFocus();
            passEditText.setError("FIELD CANNOT BE EMPTY");
        }
        else
        {
            Toast.makeText(LoginActivity.this,"Validation Successful",Toast.LENGTH_LONG).show();
            startActivity(new Intent(LoginActivity.this, DashboardActivity.class));
        }
    }
}
